Kitten Invaders
- an arcade shooter game and an homage to Space Invaders by Taito.

Kittens are invading your planet! Shoot burgers and potatoes at them to thwart their attack!

If the kittens manage to land on your planet, they will eat all your food and destroy all your furniture, and it will be game over for you.
Avoid this at all cost!

Be mindful of your ammo, though, as food is expensive. Waste not, want not.

Good luck, and good gaming!

This game was developed by Lotta Soveri